import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import OwnerDashboard from './pages/owner/Dashboard';
import OwnerProperties from './pages/owner/Properties';
import OwnerTenants from './pages/owner/Tenants';
import OwnerPayments from './pages/owner/Payments';
import OwnerComplaints from './pages/owner/Complaints';
import TenantDashboard from './pages/tenant/Dashboard';
import TenantComplaints from './pages/tenant/Complaints';
import TenantPending from './pages/tenant/Pending';

const ProtectedRoute = ({ children, allowedRole }: { children: React.ReactNode, allowedRole: 'owner' | 'tenant' }) => {
  const { user, loading } = useAuth();
  
  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/" />;
  if (user.role !== allowedRole) return <Navigate to="/" />;
  
  // If tenant is still pending, redirect to pending page
  if (allowedRole === 'tenant' && user.status === 'pending') {
    return <Navigate to="/tenant/pending" />;
  }
  
  return <>{children}</>;
};

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/onboarding" element={<Onboarding />} />
      <Route path="/tenant/pending" element={<TenantPending />} />
      
      <Route element={<Layout />}>
        <Route path="/owner" element={<ProtectedRoute allowedRole="owner"><OwnerDashboard /></ProtectedRoute>} />
        <Route path="/owner/properties" element={<ProtectedRoute allowedRole="owner"><OwnerProperties /></ProtectedRoute>} />
        <Route path="/owner/tenants" element={<ProtectedRoute allowedRole="owner"><OwnerTenants /></ProtectedRoute>} />
        <Route path="/owner/payments" element={<ProtectedRoute allowedRole="owner"><OwnerPayments /></ProtectedRoute>} />
        <Route path="/owner/complaints" element={<ProtectedRoute allowedRole="owner"><OwnerComplaints /></ProtectedRoute>} />
        
        <Route path="/tenant" element={<ProtectedRoute allowedRole="tenant"><TenantDashboard /></ProtectedRoute>} />
        <Route path="/tenant/complaints" element={<ProtectedRoute allowedRole="tenant"><TenantComplaints /></ProtectedRoute>} />
      </Route>
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </AppProvider>
    </AuthProvider>
  );
}
