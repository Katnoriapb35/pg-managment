import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCc2TloVtFedjtjZoyHJ_gC2-UbXqFi0a0",
  authDomain: "pg-managment-6f6ea.firebaseapp.com",
  projectId: "pg-managment-6f6ea",
  storageBucket: "pg-managment-6f6ea.firebasestorage.app",
  messagingSenderId: "908638056692",
  appId: "1:908638056692:web:8b4292b06d1b6c7c526ea1",
  measurementId: "G-ZNQ2RCCC3K"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
export const isConfigured = true;

