import React, { createContext, useContext, useState, useEffect } from 'react';

export type Role = 'owner' | 'tenant' | null;

export interface User {
  id: string;
  name: string;
  role: Role;
  propertyId?: string; // For tenants
}

export interface Property {
  id: string;
  name: string;
  address: string;
  ownerId: string;
}

export interface Tenant {
  id: string;
  userId: string;
  name: string;
  propertyId: string;
  roomNumber: string;
  phone: string;
  joinDate: string;
  rentAmount: number;
  noticeDate?: string;
}

export interface Payment {
  id: string;
  tenantId: string;
  amount: number;
  date: string;
  month: string;
  year: number;
  status: 'pending' | 'verified';
}

export interface Complaint {
  id: string;
  tenantId: string;
  propertyId: string;
  issue: string;
  status: 'open' | 'resolved';
  date: string;
}

interface AppState {
  currentUser: User | null;
  properties: Property[];
  tenants: Tenant[];
  payments: Payment[];
  complaints: Complaint[];
}

interface AppContextType extends AppState {
  login: (user: User) => void;
  logout: () => void;
  addProperty: (property: Omit<Property, 'id'>) => void;
  addTenant: (tenant: Omit<Tenant, 'id'>) => void;
  recordPayment: (payment: Omit<Payment, 'id' | 'status'>) => void;
  verifyPayment: (paymentId: string) => void;
  addComplaint: (complaint: Omit<Complaint, 'id' | 'status' | 'date'>) => void;
  resolveComplaint: (complaintId: string) => void;
  setNoticeDate: (tenantId: string, date: string) => void;
}

const mockOwner: User = { id: 'owner1', name: 'Rajesh Kumar', role: 'owner' };
const mockTenantUser: User = { id: 'tenant1', name: 'Amit Singh', role: 'tenant', propertyId: 'prop1' };

const initialState: AppState = {
  currentUser: null,
  properties: [
    { id: 'prop1', name: 'Sunrise PG', address: 'Koramangala, Bangalore', ownerId: 'owner1' },
    { id: 'prop2', name: 'Moonlight Stays', address: 'HSR Layout, Bangalore', ownerId: 'owner1' }
  ],
  tenants: [
    { id: 't1', userId: 'tenant1', name: 'Amit Singh', propertyId: 'prop1', roomNumber: '101', phone: '9876543210', joinDate: '2023-01-15', rentAmount: 12000 },
    { id: 't2', userId: 'tenant2', name: 'Priya Sharma', propertyId: 'prop1', roomNumber: '102', phone: '9876543211', joinDate: '2023-03-01', rentAmount: 15000 },
    { id: 't3', userId: 'tenant3', name: 'Rahul Verma', propertyId: 'prop2', roomNumber: '201', phone: '9876543212', joinDate: '2023-06-10', rentAmount: 10000 }
  ],
  payments: [
    { id: 'p1', tenantId: 't1', amount: 12000, date: '2023-10-05', month: 'October', year: 2023, status: 'verified' },
    { id: 'p2', tenantId: 't2', amount: 15000, date: '2023-10-02', month: 'October', year: 2023, status: 'verified' },
    { id: 'p3', tenantId: 't1', amount: 12000, date: '2023-11-05', month: 'November', year: 2023, status: 'pending' }
  ],
  complaints: [
    { id: 'c1', tenantId: 't1', propertyId: 'prop1', issue: 'Fan not working in room 101', status: 'open', date: '2023-11-10' }
  ]
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(initialState);

  const login = (user: User) => setState(s => ({ ...s, currentUser: user }));
  const logout = () => setState(s => ({ ...s, currentUser: null }));

  const addProperty = (property: Omit<Property, 'id'>) => {
    const newProperty = { ...property, id: `prop${Date.now()}` };
    setState(s => ({ ...s, properties: [...s.properties, newProperty] }));
  };

  const addTenant = (tenant: Omit<Tenant, 'id'>) => {
    const newTenant = { ...tenant, id: `t${Date.now()}` };
    setState(s => ({ ...s, tenants: [...s.tenants, newTenant] }));
  };

  const recordPayment = (payment: Omit<Payment, 'id' | 'status'>) => {
    const newPayment: Payment = { ...payment, id: `p${Date.now()}`, status: 'pending' };
    setState(s => ({ ...s, payments: [...s.payments, newPayment] }));
  };

  const verifyPayment = (paymentId: string) => {
    setState(s => ({
      ...s,
      payments: s.payments.map(p => p.id === paymentId ? { ...p, status: 'verified' } : p)
    }));
  };

  const addComplaint = (complaint: Omit<Complaint, 'id' | 'status' | 'date'>) => {
    const newComplaint: Complaint = {
      ...complaint,
      id: `c${Date.now()}`,
      status: 'open',
      date: new Date().toISOString().split('T')[0]
    };
    setState(s => ({ ...s, complaints: [...s.complaints, newComplaint] }));
  };

  const resolveComplaint = (complaintId: string) => {
    setState(s => ({
      ...s,
      complaints: s.complaints.map(c => c.id === complaintId ? { ...c, status: 'resolved' } : c)
    }));
  };

  const setNoticeDate = (tenantId: string, date: string) => {
    setState(s => ({
      ...s,
      tenants: s.tenants.map(t => t.id === tenantId ? { ...t, noticeDate: date } : t)
    }));
  };

  return (
    <AppContext.Provider value={{
      ...state,
      login, logout, addProperty, addTenant, recordPayment, verifyPayment, addComplaint, resolveComplaint, setNoticeDate
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
