import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { CheckCircle2, XCircle, Clock } from 'lucide-react';

export default function Payments() {
  const { payments, tenants, properties, verifyPayment } = useAppContext();

  const pendingPayments = payments.filter(p => p.status === 'pending');
  const verifiedPayments = payments.filter(p => p.status === 'verified');

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Payments</h2>
        <p className="mt-1 text-sm text-gray-500">Verify pending payments and view payment history.</p>
      </div>

      {/* Pending Verification */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6 flex justify-between items-center bg-yellow-50">
          <h3 className="text-lg leading-6 font-medium text-yellow-800">Pending Verification</h3>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            {pendingPayments.length} Pending
          </span>
        </div>
        <ul className="divide-y divide-gray-200">
          {pendingPayments.length === 0 ? (
            <li className="px-4 py-5 sm:px-6 text-sm text-gray-500 text-center">No pending payments to verify.</li>
          ) : (
            pendingPayments.map(payment => {
              const tenant = tenants.find(t => t.id === payment.tenantId);
              const property = properties.find(p => p.id === tenant?.propertyId);
              return (
                <li key={payment.id} className="px-4 py-4 sm:px-6 flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="h-8 w-8 text-yellow-400 mr-4" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{tenant?.name}</p>
                      <p className="text-sm text-gray-500">
                        {property?.name} • Room {tenant?.roomNumber} • {payment.month} {payment.year}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-sm font-semibold text-gray-900">₹{payment.amount.toLocaleString()}</p>
                      <p className="text-xs text-gray-500">{payment.date}</p>
                    </div>
                    <button
                      onClick={() => verifyPayment(payment.id)}
                      className="inline-flex items-center p-2 border border-transparent rounded-full shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                      title="Verify Payment"
                    >
                      <CheckCircle2 className="h-5 w-5" />
                    </button>
                  </div>
                </li>
              );
            })
          )}
        </ul>
      </div>

      {/* Payment History */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Recent Verified Payments</h3>
        </div>
        <ul className="divide-y divide-gray-200">
          {verifiedPayments
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(payment => {
              const tenant = tenants.find(t => t.id === payment.tenantId);
              return (
                <li key={payment.id} className="px-4 py-4 sm:px-6 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{tenant?.name}</p>
                    <p className="text-sm text-gray-500">{payment.month} {payment.year} • {payment.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-900">₹{payment.amount.toLocaleString()}</p>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 mt-1">
                      Verified
                    </span>
                  </div>
                </li>
              );
            })}
        </ul>
      </div>
    </div>
  );
}
