import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../lib/firebase';
import { collection, addDoc, getDocs, query, where } from 'firebase/firestore';
import { Building2, Plus, MapPin } from 'lucide-react';

export default function Properties() {
  const { properties, addProperty } = useAppContext();
  const { user } = useAuth();
  const [isAdding, setIsAdding] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [firebaseProperties, setFirebaseProperties] = useState<any[]>([]);

  useEffect(() => {
    const fetchProps = async () => {
      if (!db || !user) return;
      const q = query(collection(db, 'properties'), where('ownerId', '==', user.uid));
      const snapshot = await getDocs(q);
      setFirebaseProperties(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchProps();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !address.trim() || !user || !db) return;

    const newProp = {
      name: name.trim(),
      address: address.trim(),
      ownerId: user.uid
    };

    const docRef = await addDoc(collection(db, 'properties'), newProp);
    
    setFirebaseProperties([...firebaseProperties, { id: docRef.id, ...newProp }]);
    
    // Also add to local context for demo purposes
    addProperty(newProp);
    
    setName('');
    setAddress('');
    setIsAdding(false);
  };

  const displayProperties = firebaseProperties.length > 0 ? firebaseProperties : properties;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">My Properties</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Property
        </button>
      </div>

      {isAdding && (
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">Add New Property</h3>
            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Property Name</label>
                <input
                  type="text"
                  id="name"
                  className="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                <textarea
                  id="address"
                  rows={2}
                  className="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                />
              </div>
              <div className="flex items-center space-x-3">
                <button
                  type="submit"
                  className="inline-flex items-center justify-center px-4 py-2 border border-transparent font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm"
                >
                  Save Property
                </button>
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {displayProperties.map((property) => (
          <div key={property.id} className="bg-white overflow-hidden shadow rounded-lg divide-y divide-gray-200">
            <div className="px-4 py-5 sm:px-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-indigo-100 rounded-md p-3">
                  <Building2 className="h-6 w-6 text-indigo-600" />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">{property.name}</h3>
                </div>
              </div>
            </div>
            <div className="px-4 py-4 sm:px-6">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                <p className="text-sm text-gray-500">{property.address}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
