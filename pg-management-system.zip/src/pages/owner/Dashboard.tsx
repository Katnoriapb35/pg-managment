import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { IndianRupee, Users, Building2, AlertCircle } from 'lucide-react';

export default function Dashboard() {
  const { properties, tenants, payments, complaints } = useAppContext();

  const totalCollected = payments
    .filter(p => p.status === 'verified' && p.month === 'October') // Hardcoded to current month for demo
    .reduce((sum, p) => sum + p.amount, 0);

  const totalExpected = tenants.reduce((sum, t) => sum + t.rentAmount, 0);
  const totalPending = totalExpected - totalCollected;

  const defaulters = tenants.filter(t => {
    const hasPaid = payments.some(p => p.tenantId === t.id && p.month === 'October' && p.status === 'verified');
    return !hasPaid;
  });

  const openComplaints = complaints.filter(c => c.status === 'open');

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Dashboard Overview</h2>
        <p className="mt-1 text-sm text-gray-500">Here's what's happening with your properties today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <IndianRupee className="h-6 w-6 text-green-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Collected (Oct)</dt>
                  <dd className="text-lg font-semibold text-gray-900">₹{totalCollected.toLocaleString()}</dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <IndianRupee className="h-6 w-6 text-red-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Pending (Oct)</dt>
                  <dd className="text-lg font-semibold text-gray-900">₹{totalPending.toLocaleString()}</dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-indigo-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Tenants</dt>
                  <dd className="text-lg font-semibold text-gray-900">{tenants.length}</dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Building2 className="h-6 w-6 text-blue-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Properties</dt>
                  <dd className="text-lg font-semibold text-gray-900">{properties.length}</dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Defaulters List */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 border-b border-gray-200 sm:px-6 flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-gray-900">Defaulters (Oct)</h3>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
              {defaulters.length} Pending
            </span>
          </div>
          <ul className="divide-y divide-gray-200">
            {defaulters.length === 0 ? (
              <li className="px-4 py-5 sm:px-6 text-sm text-gray-500 text-center">All tenants have paid!</li>
            ) : (
              defaulters.map(tenant => (
                <li key={tenant.id} className="px-4 py-4 sm:px-6 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-indigo-600 truncate">{tenant.name}</p>
                    <p className="text-sm text-gray-500">Room {tenant.roomNumber} • {properties.find(p => p.id === tenant.propertyId)?.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-900">₹{tenant.rentAmount.toLocaleString()}</p>
                    <p className="text-xs text-red-500 font-medium">Overdue</p>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* Recent Complaints */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 border-b border-gray-200 sm:px-6 flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-gray-900">Open Complaints</h3>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
              {openComplaints.length} Open
            </span>
          </div>
          <ul className="divide-y divide-gray-200">
            {openComplaints.length === 0 ? (
              <li className="px-4 py-5 sm:px-6 text-sm text-gray-500 text-center">No open complaints.</li>
            ) : (
              openComplaints.map(complaint => {
                const tenant = tenants.find(t => t.id === complaint.tenantId);
                return (
                  <li key={complaint.id} className="px-4 py-4 sm:px-6">
                    <div className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-yellow-400 mt-0.5 mr-3" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">{complaint.issue}</p>
                        <p className="text-sm text-gray-500 mt-1">
                          {tenant?.name} (Room {tenant?.roomNumber}) • {complaint.date}
                        </p>
                      </div>
                    </div>
                  </li>
                );
              })
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
