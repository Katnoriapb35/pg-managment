import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../lib/firebase';
import { collection, query, where, getDocs, doc, updateDoc, setDoc } from 'firebase/firestore';
import { Users, Plus, Phone, Calendar, IndianRupee, CheckCircle2, XCircle } from 'lucide-react';

export default function Tenants() {
  const { tenants, properties, addTenant } = useAppContext();
  const { user } = useAuth();
  const [isAdding, setIsAdding] = useState(false);
  const [requests, setRequests] = useState<any[]>([]);
  
  const [formData, setFormData] = useState({
    name: '',
    propertyId: properties[0]?.id || '',
    roomNumber: '',
    phone: '',
    joinDate: new Date().toISOString().split('T')[0],
    rentAmount: ''
  });

  useEffect(() => {
    const fetchRequests = async () => {
      if (!db) return;
      const q = query(collection(db, 'roomRequests'), where('status', '==', 'pending'));
      const snapshot = await getDocs(q);
      setRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchRequests();
  }, []);

  const handleApproveRequest = async (request: any) => {
    if (!db) return;
    
    // 1. Update request status
    await updateDoc(doc(db, 'roomRequests', request.id), { status: 'approved' });
    
    // 2. Update user status in users collection
    await updateDoc(doc(db, 'users', request.userId), { 
      status: 'approved',
      propertyId: request.propertyId,
      roomNumber: request.roomNumber
    });

    // 3. Add to local AppContext (in a real app, we'd sync everything with Firestore)
    addTenant({
      userId: request.userId,
      name: request.userName,
      propertyId: request.propertyId,
      roomNumber: request.roomNumber,
      phone: 'Pending', // Tenant can fill this later
      joinDate: new Date().toISOString().split('T')[0],
      rentAmount: 10000 // Default, owner can edit later
    });

    setRequests(requests.filter(r => r.id !== request.id));
    alert('Tenant approved successfully!');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addTenant({
      userId: `user_${Date.now()}`, // Mock user ID for new tenant
      name: formData.name,
      propertyId: formData.propertyId,
      roomNumber: formData.roomNumber,
      phone: formData.phone,
      joinDate: formData.joinDate,
      rentAmount: Number(formData.rentAmount)
    });
    setIsAdding(false);
    setFormData({ ...formData, name: '', roomNumber: '', phone: '', rentAmount: '' });
  };

  return (
    <div className="space-y-8">
      {requests.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Pending Room Requests</h2>
          <div className="bg-white shadow overflow-hidden sm:rounded-md">
            <ul className="divide-y divide-gray-200">
              {requests.map((req) => (
                <li key={req.id} className="px-4 py-4 sm:px-6 bg-yellow-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-indigo-600">{req.userName}</p>
                      <p className="text-sm text-gray-500">
                        Requested Room {req.roomNumber} • {properties.find(p => p.id === req.propertyId)?.name || 'Unknown Property'}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">{req.userEmail}</p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleApproveRequest(req)}
                        className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle2 className="mr-1.5 h-4 w-4" />
                        Approve
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-gray-900">Active Tenants</h2>
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Tenant
          </button>
        </div>

        {isAdding && (
          <div className="bg-white shadow sm:rounded-lg mb-6">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Add New Tenant</h3>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Full Name</label>
                  <input type="text" required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Property</label>
                  <select required className="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value={formData.propertyId} onChange={e => setFormData({...formData, propertyId: e.target.value})}>
                    {properties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Room Number</label>
                  <input type="text" required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value={formData.roomNumber} onChange={e => setFormData({...formData, roomNumber: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone Number</label>
                  <input type="tel" required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Monthly Rent (₹)</label>
                  <input type="number" required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value={formData.rentAmount} onChange={e => setFormData({...formData, rentAmount: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Join Date</label>
                  <input type="date" required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value={formData.joinDate} onChange={e => setFormData({...formData, joinDate: e.target.value})} />
                </div>
                <div className="sm:col-span-2 flex justify-end space-x-3">
                  <button type="button" onClick={() => setIsAdding(false)} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
                  <button type="submit" className="bg-indigo-600 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Save Tenant</button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {tenants.map((tenant) => (
              <li key={tenant.id}>
                <div className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                        <span className="text-indigo-600 font-medium text-lg">{tenant.name.charAt(0)}</span>
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-indigo-600 truncate">{tenant.name}</p>
                        <p className="text-sm text-gray-500">
                          {properties.find(p => p.id === tenant.propertyId)?.name} • Room {tenant.roomNumber}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="flex items-center text-sm text-gray-900 font-semibold">
                        <IndianRupee className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        {tenant.rentAmount.toLocaleString()}/mo
                      </div>
                      {tenant.noticeDate && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 mt-1">
                          Vacating: {tenant.noticeDate}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex sm:space-x-6">
                      <p className="flex items-center text-sm text-gray-500">
                        <Phone className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        {tenant.phone}
                      </p>
                      <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                        <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        Joined {tenant.joinDate}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
