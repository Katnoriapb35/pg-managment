import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export default function Complaints() {
  const { complaints, tenants, properties, resolveComplaint } = useAppContext();

  const openComplaints = complaints.filter(c => c.status === 'open');
  const resolvedComplaints = complaints.filter(c => c.status === 'resolved');

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Tenant Complaints</h2>
        <p className="mt-1 text-sm text-gray-500">Manage and resolve maintenance issues.</p>
      </div>

      {/* Open Complaints */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6 flex justify-between items-center bg-red-50">
          <h3 className="text-lg leading-6 font-medium text-red-800">Open Issues</h3>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            {openComplaints.length} Open
          </span>
        </div>
        <ul className="divide-y divide-gray-200">
          {openComplaints.length === 0 ? (
            <li className="px-4 py-5 sm:px-6 text-sm text-gray-500 text-center">No open complaints!</li>
          ) : (
            openComplaints.map(complaint => {
              const tenant = tenants.find(t => t.id === complaint.tenantId);
              const property = properties.find(p => p.id === complaint.propertyId);
              return (
                <li key={complaint.id} className="px-4 py-4 sm:px-6 flex items-start justify-between">
                  <div className="flex items-start">
                    <AlertCircle className="h-6 w-6 text-red-500 mr-3 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{complaint.issue}</p>
                      <p className="text-sm text-gray-500 mt-1">
                        {tenant?.name} • {property?.name} (Room {tenant?.roomNumber})
                      </p>
                      <p className="text-xs text-gray-400 mt-1">Reported on {complaint.date}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => resolveComplaint(complaint.id)}
                    className="ml-4 inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Mark Resolved
                  </button>
                </li>
              );
            })
          )}
        </ul>
      </div>

      {/* Resolved Complaints */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Recently Resolved</h3>
        </div>
        <ul className="divide-y divide-gray-200">
          {resolvedComplaints.map(complaint => {
            const tenant = tenants.find(t => t.id === complaint.tenantId);
            return (
              <li key={complaint.id} className="px-4 py-4 sm:px-6 flex items-start">
                <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-900 line-through text-gray-500">{complaint.issue}</p>
                  <p className="text-sm text-gray-500 mt-1">
                    {tenant?.name} • Room {tenant?.roomNumber}
                  </p>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
