import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { IndianRupee, Calendar, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Dashboard() {
  const { tenants, payments, properties, recordPayment } = useAppContext();
  const { user } = useAuth();
  
  // Find tenant by userId, fallback to mock if not found (for demo purposes)
  const tenant = tenants.find(t => t.userId === user?.uid) || tenants.find(t => t.userId === 'tenant1');
  const property = properties.find(p => p.id === tenant?.propertyId);
  
  // Current month hardcoded for demo
  const currentMonth = 'October';
  const currentYear = 2023;
  
  const currentPayment = payments.find(p => 
    p.tenantId === tenant?.id && 
    p.month === currentMonth && 
    p.year === currentYear
  );

  const handlePayNow = () => {
    if (!tenant) return;
    
    // Simulate UPI Deep Link
    const upiId = 'owner@upi';
    const name = 'Rajesh Kumar';
    const amount = tenant.rentAmount;
    const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&am=${amount}&cu=INR`;
    
    // In a real app, we would use window.location.href = upiUrl;
    // For this demo, we'll just record the payment as pending
    alert(`Simulating UPI Deep Link:\n${upiUrl}\n\nPayment marked as pending verification by owner.`);
    
    recordPayment({
      tenantId: tenant.id,
      amount: tenant.rentAmount,
      date: new Date().toISOString().split('T')[0],
      month: currentMonth,
      year: currentYear
    });
  };

  if (!tenant) return <div>Tenant not found</div>;

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 bg-indigo-600 text-white">
          <h3 className="text-lg leading-6 font-medium">My Rent - {currentMonth} {currentYear}</h3>
          <p className="mt-1 max-w-2xl text-sm text-indigo-100">
            {property?.name} • Room {tenant.roomNumber}
          </p>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
          <dl className="sm:divide-y sm:divide-gray-200">
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Rent Amount</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2 font-semibold text-lg">
                ₹{tenant.rentAmount.toLocaleString()}
              </dd>
            </div>
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Status</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {!currentPayment ? (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                    <AlertCircle className="w-4 h-4 mr-1" /> Unpaid
                  </span>
                ) : currentPayment.status === 'pending' ? (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    <AlertCircle className="w-4 h-4 mr-1" /> Pending Verification
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <CheckCircle2 className="w-4 h-4 mr-1" /> Paid
                  </span>
                )}
              </dd>
            </div>
          </dl>
        </div>
        
        {!currentPayment && (
          <div className="bg-gray-50 px-4 py-4 sm:px-6 flex justify-end">
            <button
              onClick={handlePayNow}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <IndianRupee className="mr-2 h-4 w-4" />
              Pay Now via UPI
            </button>
          </div>
        )}
      </div>

      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Payment History</h3>
        </div>
        <ul className="divide-y divide-gray-200">
          {payments
            .filter(p => p.tenantId === tenant.id)
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(payment => (
              <li key={payment.id} className="px-4 py-4 sm:px-6 flex items-center justify-between">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{payment.month} {payment.year}</p>
                    <p className="text-sm text-gray-500">{payment.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-900">₹{payment.amount.toLocaleString()}</p>
                  <p className={`text-xs font-medium ${payment.status === 'verified' ? 'text-green-600' : 'text-yellow-600'}`}>
                    {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                  </p>
                </div>
              </li>
            ))}
        </ul>
      </div>
    </div>
  );
}
