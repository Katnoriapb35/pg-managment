import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Clock, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function TenantPending() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'pending' | 'approved' | 'loading'>('loading');

  useEffect(() => {
    const checkStatus = async () => {
      if (!user || !db) return;
      
      // Check if user is already fully approved in users collection
      if (user.status === 'approved') {
        navigate('/tenant');
        return;
      }

      // Check request status
      const q = query(collection(db, 'roomRequests'), where('userId', '==', user.uid));
      const snapshot = await getDocs(q);
      
      if (!snapshot.empty) {
        const request = snapshot.docs[0].data();
        if (request.status === 'approved') {
          setStatus('approved');
          // In a real app, we'd update the user context here or force a reload
          setTimeout(() => window.location.reload(), 2000);
        } else {
          setStatus('pending');
        }
      } else {
        // No request found, redirect to onboarding
        navigate('/onboarding');
      }
    };

    checkStatus();
  }, [user, navigate]);

  if (status === 'loading') {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="flex justify-center mb-4">
          {status === 'pending' ? (
            <Clock className="h-16 w-16 text-yellow-500" />
          ) : (
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          )}
        </div>
        <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
          {status === 'pending' ? 'Approval Pending' : 'Approved!'}
        </h2>
        <p className="mt-2 text-sm text-gray-600">
          {status === 'pending' 
            ? 'Your room request has been sent to the owner. Once they verify your security deposit and approve your request, you will be able to access your dashboard.'
            : 'Your request has been approved. Redirecting to your dashboard...'}
        </p>
      </div>
    </div>
  );
}
