import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { AlertCircle, CheckCircle2, Plus } from 'lucide-react';

export default function Complaints() {
  const { tenants, complaints, addComplaint } = useAppContext();
  const { user } = useAuth();
  const [isAdding, setIsAdding] = useState(false);
  const [issue, setIssue] = useState('');

  const tenant = tenants.find(t => t.userId === user?.uid) || tenants.find(t => t.userId === 'tenant1');
  const myComplaints = complaints.filter(c => c.tenantId === tenant?.id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenant || !issue.trim()) return;

    addComplaint({
      tenantId: tenant.id,
      propertyId: tenant.propertyId,
      issue: issue.trim()
    });
    setIssue('');
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">My Complaints</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Raise Issue
        </button>
      </div>

      {isAdding && (
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">Report a Maintenance Issue</h3>
            <div className="mt-2 max-w-xl text-sm text-gray-500">
              <p>Please describe the issue in your room or common areas.</p>
            </div>
            <form onSubmit={handleSubmit} className="mt-5">
              <div className="w-full sm:max-w-xs">
                <label htmlFor="issue" className="sr-only">Issue</label>
                <textarea
                  id="issue"
                  rows={3}
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                  placeholder="E.g., Fan is making noise, Tap is leaking..."
                  value={issue}
                  onChange={(e) => setIssue(e.target.value)}
                  required
                />
              </div>
              <div className="mt-3 flex items-center space-x-3">
                <button
                  type="submit"
                  className="inline-flex items-center justify-center px-4 py-2 border border-transparent font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm"
                >
                  Submit
                </button>
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {myComplaints.length === 0 ? (
            <li className="px-4 py-5 sm:px-6 text-sm text-gray-500 text-center">No complaints raised yet.</li>
          ) : (
            myComplaints.map(complaint => (
              <li key={complaint.id} className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {complaint.status === 'open' ? (
                      <AlertCircle className="h-5 w-5 text-yellow-400 mr-3" />
                    ) : (
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-3" />
                    )}
                    <p className="text-sm font-medium text-gray-900">{complaint.issue}</p>
                  </div>
                  <div className="ml-2 flex-shrink-0 flex">
                    <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      complaint.status === 'open' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {complaint.status.charAt(0).toUpperCase() + complaint.status.slice(1)}
                    </p>
                  </div>
                </div>
                <div className="mt-2 sm:flex sm:justify-between">
                  <div className="sm:flex">
                    <p className="flex items-center text-sm text-gray-500">
                      Reported on {complaint.date}
                    </p>
                  </div>
                </div>
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  );
}
