import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Building2, User } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, addDoc, getDocs } from 'firebase/firestore';

export default function Onboarding() {
  const { user, setUserRole } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'role' | 'tenant-request'>('role');
  const [properties, setProperties] = useState<any[]>([]);
  const [selectedProperty, setSelectedProperty] = useState('');
  const [roomNumber, setRoomNumber] = useState('');

  const handleOwnerSelect = async () => {
    setLoading(true);
    await setUserRole('owner');
    navigate('/owner');
  };

  const handleTenantSelect = async () => {
    setLoading(true);
    // Fetch properties to let tenant choose
    if (db) {
      const propsSnapshot = await getDocs(collection(db, 'properties'));
      const propsList = propsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProperties(propsList);
    }
    setStep('tenant-request');
    setLoading(false);
  };

  const handleRoomRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProperty || !roomNumber || !user || !db) return;
    setLoading(true);

    // Create a room request
    await addDoc(collection(db, 'roomRequests'), {
      userId: user.uid,
      userName: user.displayName,
      userEmail: user.email,
      propertyId: selectedProperty,
      roomNumber,
      status: 'pending',
      createdAt: new Date().toISOString()
    });

    // Set role to tenant, but status is pending
    await setUserRole('tenant');
    navigate('/tenant/pending');
  };

  if (step === 'role') {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">Welcome, {user?.displayName}!</h2>
          <p className="mt-2 text-sm text-gray-600">Please select your role to continue.</p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 space-y-6">
            <button
              onClick={handleOwnerSelect}
              disabled={loading}
              className="w-full flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
            >
              <Building2 className="mr-3 h-6 w-6" />
              I am a PG Owner
            </button>

            <button
              onClick={handleTenantSelect}
              disabled={loading}
              className="w-full flex items-center justify-center px-8 py-4 border-2 border-indigo-600 text-base font-medium rounded-xl text-indigo-700 bg-white hover:bg-indigo-50 disabled:opacity-50"
            >
              <User className="mr-3 h-6 w-6" />
              I am a Tenant
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <h2 className="mt-6 text-3xl font-extrabold text-gray-900">Request a Room</h2>
        <p className="mt-2 text-sm text-gray-600">Select the property and enter your room number.</p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <form onSubmit={handleRoomRequest} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Select Property</label>
              <select
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md border"
                value={selectedProperty}
                onChange={(e) => setSelectedProperty(e.target.value)}
              >
                <option value="">-- Choose a Property --</option>
                {properties.map(p => (
                  <option key={p.id} value={p.id}>{p.name} ({p.address})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Room Number</label>
              <input
                type="text"
                required
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                value={roomNumber}
                onChange={(e) => setRoomNumber(e.target.value)}
                placeholder="e.g. 101"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              {loading ? 'Submitting...' : 'Submit Request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
