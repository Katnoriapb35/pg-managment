import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Building2, LogIn, AlertTriangle } from 'lucide-react';

export default function Login() {
  const { loginWithGoogle, isFirebaseConfigured, user } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (user) {
      if (user.role === 'owner') navigate('/owner');
      else if (user.role === 'tenant') navigate('/tenant');
      else navigate('/onboarding');
    }
  }, [user, navigate]);

  if (!isFirebaseConfigured) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
            <div className="flex items-center justify-center text-yellow-500 mb-4">
              <AlertTriangle className="h-12 w-12" />
            </div>
            <h2 className="text-center text-xl font-bold text-gray-900 mb-4">Firebase Setup Required</h2>
            <p className="text-sm text-gray-600 mb-4 text-center">
              To enable real Google Sign-In and database features, you need to configure Firebase.
            </p>
            <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2 mb-6">
              <li>Go to Firebase Console and create a project.</li>
              <li>Enable Google Authentication.</li>
              <li>Create a Firestore Database.</li>
              <li>Add the config values to your <code className="bg-gray-100 px-1 rounded">.env</code> file.</li>
            </ol>
            <p className="text-xs text-gray-500 text-center">
              Check the .env.example file for the required variables.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="h-16 w-16 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Building2 className="h-8 w-8 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          PG Management System
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Sign in to manage your properties or pay rent
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <button
            onClick={loginWithGoogle}
            className="w-full flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all shadow-sm hover:shadow"
          >
            <LogIn className="mr-3 h-6 w-6" />
            Sign in with Google
          </button>
        </div>
      </div>
    </div>
  );
}
