import React from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Home, Users, DollarSign, AlertCircle, LogOut, Menu } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  if (!user) {
    return <Outlet />;
  }

  const ownerNav = [
    { name: 'Dashboard', path: '/owner', icon: Home },
    { name: 'Properties', path: '/owner/properties', icon: Home },
    { name: 'Tenants', path: '/owner/tenants', icon: Users },
    { name: 'Payments', path: '/owner/payments', icon: DollarSign },
    { name: 'Complaints', path: '/owner/complaints', icon: AlertCircle },
  ];

  const tenantNav = [
    { name: 'My Rent', path: '/tenant', icon: DollarSign },
    { name: 'Complaints', path: '/tenant/complaints', icon: AlertCircle },
  ];

  const navItems = user.role === 'owner' ? ownerNav : tenantNav;

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b border-gray-200 p-4 flex justify-between items-center">
        <h1 className="text-xl font-bold text-indigo-600">PG Manager</h1>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-gray-500">
          <Menu size={24} />
        </button>
      </div>

      {/* Sidebar */}
      <div className={cn(
        "bg-white border-r border-gray-200 w-full md:w-64 flex-shrink-0 flex-col transition-all duration-300 ease-in-out",
        isMobileMenuOpen ? "flex" : "hidden md:flex"
      )}>
        <div className="p-6 hidden md:block">
          <h1 className="text-2xl font-bold text-indigo-600">PG Manager</h1>
        </div>
        
        <div className="p-4 border-b border-gray-100">
          <p className="text-sm text-gray-500">Logged in as</p>
          <p className="font-medium text-gray-900">{user.displayName}</p>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 mt-1 capitalize">
            {user.role}
          </span>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.name}
                onClick={() => {
                  navigate(item.path);
                  setIsMobileMenuOpen(false);
                }}
                className={cn(
                  "w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors",
                  isActive 
                    ? "bg-indigo-50 text-indigo-700" 
                    : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                <Icon className={cn("mr-3 h-5 w-5", isActive ? "text-indigo-700" : "text-gray-400")} />
                {item.name}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-200">
          <button
            onClick={handleLogout}
            className="w-full flex items-center px-4 py-3 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50 transition-colors"
          >
            <LogOut className="mr-3 h-5 w-5 text-red-500" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
